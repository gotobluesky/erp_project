
<div class="modal-body">

    <div class="form-group">
        <label class="form-label" for="exampleFormControlTextarea1">{{__('Description')}}</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" readonly>{{$termination->description}}</textarea>
    </div>

</div>






